<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login_admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Painel do Administrador</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .bg-laranja {
      background-color: #ff8000 !important;
    }
  </style>
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="card shadow">
    <div class="card-header bg-laranja text-white">
      <h4>Painel do Administrador</h4>
    </div>
    <div class="card-body">
      <p>Olá, <strong><?= $_SESSION['admin'] ?></strong>! Bem-vindo ao sistema de gestão.</p>
      <a href="logout.php" class="btn btn-danger">Terminar Sessão</a>
    </div>
  </div>
</div>

</body>
</html>