<?php
session_start();
include 'menu.php';

if (!isset($_SESSION['admin'])) {
    header("Location: AdminLogin.php");
    exit;
}


$conn = new mysqli("localhost", "root", "", "GestaoEscola");
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$sqlAlunos = "SELECT COUNT(*) AS total FROM alunos";
$resAlunos = $conn->query($sqlAlunos);
$totalAlunos = 0;
if ($resAlunos->num_rows > 0) {
    $row = $resAlunos->fetch_assoc();
    $totalAlunos = $row['total'];
}
$sqlProfessores = "SELECT COUNT(*) AS total FROM professores";
$resProfessores = $conn->query($sqlProfessores);
$totalProfessores = 0;
if($resProfessores->num_rows > 0){
    $row = $resProfessores->fetch_assoc();
    $totalProfessores = $row['total'];
}
$sqlDisciplinas = "SELECT COUNT(*) AS total FROM disciplinas";
$resDisciplinas = $conn->query($sqlDisciplinas);
$totalDisciplinas = 0;
if($resDisciplinas->num_rows > 0){
    $row = $resDisciplinas->fetch_assoc();
    $totalDisciplinas = $row['total'];
}
?>


<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Dashboard do Administrador</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background-color: #f2f2f2;
    }
    .text-purple {
    color: #6f42c1;
    }
    .text-purple:hover {
    color: #5a32a3;
    }
    .container-conteudo {
      margin-top: 40px;
    }

    .card {
      border-radius: 15px;
    }
  </style>
</head>
<body>

<div class="container container-conteudo">
  <div class="row g-4">

    <div class="col-md-3">
    <div class="card text-center shadow-sm border-0 text-dark" style="background-color: #d0ebff;">
    <div class="card-body">
      <h6 class="card-title mb-2">
        <?= $totalAlunos ?> <?= $totalAlunos == 1 ? 'Aluno' : 'Alunos' ?>
      </h6>
      <a href="veralunos.php" class="text-decoration-none small text-dark">Saber mais</a>
    </div>
  </div>
</div>

    <div class="col-md-3">
      <div class="card text-center shadow-sm border-0 text-dark" style="background-color: #d3f9d8;">
        <div class="card-body">
            <h6 class="card-title mb-2">
                <?= $totalProfessores ?> <?= $totalProfessores == 1 ? 'Professor' : 'Professores' ?>
            </h6>
          <a href="verprofessor.php" class="text-decoration-none small text-dark">Saber mais</a>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card text-center shadow-sm border-0 text-dark" style="background-color: #ffe3e3;">
        <div class="card-body">
            <h6 class="card-title mb-2">
            <?= $totalDisciplinas ?> <?= $totalDisciplinas == 1 ? 'Disciplina' : 'Disciplinas' ?>
            </h6>
          <a href="verdisciplinas" class="text-decoration-none small text-dark">Saber mais</a>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card text-center shadow-sm border-0 text-dark" style="background-color: #e5dbff;">
        <div class="card-body">
          <h6 class="card-title mb-2">Estatisca Geral</h6>
          <a href="#" class="text-decoration-none small text-dark">Saber mais</a>
        </div>
      </div>
    </div>

  </div>
</div>


  </div>
</div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>