<?php
session_start();
$conn = new mysqli("localhost", "root", "", "GestaoEscola");

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senhaDigitada = $_POST['senha'];

    $sql = "SELECT * FROM alunos WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
        $senhaSalva = $usuario['senha'];

        if (password_get_info($senhaSalva)['algo'] !== 0) {
            if (password_verify($senhaDigitada, $senhaSalva)) {
                $_SESSION['aluno'] = $email;
                header("Location: dashboardaluno.php");
                exit;
            } else {
                $mensagem = "<div class='alert alert-danger text-center'>Senha incorreta!</div>";
            }

        } else {
            if ($senhaDigitada === $senhaSalva) {
                $novaSenhaHash = password_hash($senhaDigitada, PASSWORD_DEFAULT);

                $update = $conn->prepare("UPDATE alunos SET senha = ? WHERE email = ?");
                $update->bind_param("ss", $novaSenhaHash, $email);
                $update->execute();

                $_SESSION['aluno'] = $email;
                header("Location: dashboardaluno.php");
                exit;
            } else {
                $mensagem = "<div class='alert alert-danger text-center'>Senha incorreta!</div>";
            }
        }

    } else {
        $mensagem = "<div class='alert alert-danger text-center'>E-mail não encontrado!</div>";
    }
}
?>


<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Login do Alunos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f2f2f2;
    }

    .card-login {
      max-width: 400px;
      margin: auto;
      margin-top: 8%;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      background-color: #ffffff;
    }

    .titulo-laranja {
      color: #ff8000;
    }

    .btn-laranja {
      background-color: #ff8000;
      color: white;
    }

    .btn-laranja:hover {
      background-color: #e67300;
    }
  </style>
</head>
<body>

  <div class="card card-login">
    <h4 class="text-center titulo-laranja mb-4">Login do Aluno</h4>

    <?php echo $mensagem; ?>

    <form method="POST">
      <div class="mb-3">
        <label class="form-label">E-mail</label>
        <input type="email" name="email" class="form-control rounded-pill" required>
      </div>

      <div class="mb-4">
        <label class="form-label">Senha</label>
        <input type="password" name="senha" class="form-control rounded-pill" required>
      </div>

      <button type="submit" class="btn btn-laranja w-100 rounded-pill mb-3">Entrar</button>

      <div class="text-center">
        <span>Não tem conta?</span>
        <a href="#" class="text-decoration-none titulo-laranja fw-bold" onclick="cadastrar()">Cadastrar-se</a>
      </div>
    </form>
  </div>

  <script>
    function cadastrar(){
        alert("Somente o administrador pode cadastrar aluno 🙂");
    }
  </script>
</body>
</html>