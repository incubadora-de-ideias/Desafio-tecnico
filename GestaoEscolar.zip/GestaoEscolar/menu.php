<?php 
$pagina_atual = basename($_SERVER['PHP_SELF']);
?>

<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <p class="navbar-brand fw-bold">Painel Admin</p>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuResponsivo"                 aria-controls="menuResponsivo" aria-expanded="false" aria-label="Alternar navegação">
    <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="menuResponsivo">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link <?php if($pagina_atual == 'dashboardadmin.php') echo 'active'; ?>" href="dashboardadmin.php">Início</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($pagina_atual == 'cadastros.php') echo 'active'; ?>" href="cadastros.php">Cadastrar</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($pagina_atual == 'relatorios.php') echo 'active'; ?>" href="#">Relatórios</a>
        </li>
      </ul>
      <span class="navbar-text me-3">
        Olá, <?= $_SESSION['admin'] ?>
      </span>
      <a href="AdminLogin.php" class="btn btn-light btn-sm">Sair</a>
    </div>
  </div>
</nav>

<style>
  .navbar {
    background-color: #ff8000;
  }

  .nav-link, .navbar-brand, .navbar-text {
    color: white !important;
  }

  .nav-link:hover {
    color: #ffd6a0 !important;
  }

  .nav-link.active {
    border-bottom: 2px solid white;
    font-weight: bold;
  }
</style>