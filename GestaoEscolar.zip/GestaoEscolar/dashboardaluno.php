<?php 

session_start();
include 'menualuno.php';

$conn = new mysqli("localhost", "root", "", "GestaoEscola");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$sql = "SELECT n.id, d.nome_disciplina AS disciplina, n.nota1, n.nota2,
        ROUND((n.nota1 + n.nota2) / 2, 2) AS media
        FROM notas n
        JOIN disciplinas d ON n.id_disciplina = d.id
        WHERE n.id_aluno = 3";

$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Painel Aluno</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
    }
    .titulo {
      color: #ff8000;
    }
    .table thead {
      background-color: #ff8000;
      color: white;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <h2 class="text-center mb-4 titulo">Minhas Notas</h2>

  <?php if ($resultado->num_rows > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered table-hover">
        <thead class="text-center">
          <tr>
            <th>ID</th>
            <th>Disciplina</th>
            <th>Nota1</th>
            <th>Nota2</th>
            <th>Media</th>
          </tr>
        </thead>
        <tbody>
          <?php while($linha = $resultado->fetch_assoc()): ?>
            <tr>
              <td><?= $linha["id"] ?></td>
              <td><?= $linha["disciplina"] ?></td>
              <td><?= $linha["nota1"] ?></td>
              <td><?= $linha["nota2"] ?></td>
              <td><?= $linha["media"] ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="alert alert-warning text-center">Sem notas ainda.</div>
  <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>