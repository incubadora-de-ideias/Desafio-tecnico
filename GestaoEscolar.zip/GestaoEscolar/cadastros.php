<?php 

session_start();
include 'menu.php';

$conn = new mysqli("localhost", "root", "", "GestaoEscola");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Cadastro de Usuários</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light text-center">

  <div class="container mt-5">
    <h2 class="mb-4">Cadastrar Usuário</h2>
    
    <div class="d-flex justify-content-center gap-4">
      <a href="cadastroaluno.php" class="btn btn-primary btn-lg">Cadastrar Aluno</a>
      <a href="cadastroprofessor.php" class="btn btn-success btn-lg">Cadastrar Professor</a>
    </div>
  </div>

</body>
</html>