<?php
$conn = new mysqli("localhost", "root", "", "GestaoEscola");
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$mensagem = "";
$aluno = null;

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM alunos WHERE id = $id";
    $resultado = $conn->query($sql);

    if ($resultado->num_rows == 1) {
        $aluno = $resultado->fetch_assoc();
    } else {
        $mensagem = "<div class='alert alert-danger'>Aluno não encontrado.</div>";
    }
} else {
    $mensagem = "<div class='alert alert-danger'>ID inválido.</div>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id']) && $aluno) {
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $genero = $_POST['genero'];
    $sala = $_POST['sala'];

    $sql = "UPDATE alunos SET nome=?, idade=?, genero=?, sala=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sissi", $nome, $idade, $genero, $sala, $id);

    if ($stmt->execute()) {
        $mensagem = "<div class='alert alert-success'>Dados atualizados com sucesso!</div>";
        $aluno['nome'] = $nome;
        $aluno['idade'] = $idade;
        $aluno['genero'] = $genero;
        $aluno['sala'] = $sala;
    } else {
        $mensagem = "<div class='alert alert-danger'>Erro ao atualizar: " . $stmt->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Editar Aluno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --cor-principal: #ff8000;
        }
        .bg-laranja {
            background-color: var(--cor-principal);
        }
        .btn-laranja {
            background-color: var(--cor-principal);
            color: white;
        }
        .btn-laranja:hover {
            background-color: #e67300;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-laranja text-white">
            <h4>Editar Aluno</h4>
        </div>
        <div class="card-body">
            <?= $mensagem ?>

            <?php if ($aluno): ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nome</label>
                    <input type="text" name="nome" class="form-control" value="<?= $aluno['nome'] ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Idade</label>
                    <input type="number" name="idade" class="form-control" value="<?= $aluno['idade'] ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Gênero</label>
                    <select name="genero" class="form-select" required>
                        <option value="M" <?= $aluno['genero'] == 'M' ? 'selected' : '' ?>>Masculino</option>
                        <option value="F" <?= $aluno['genero'] == 'F' ? 'selected' : '' ?>>Feminino</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Sala</label>
                    <input type="text" name="sala" class="form-control" value="<?= $aluno['sala'] ?>" required>
                </div>
                <button type="submit" class="btn btn-laranja">Salvar Alterações</button>
                <a href="listar_alunos.php" class="btn btn-secondary">Voltar</a>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>