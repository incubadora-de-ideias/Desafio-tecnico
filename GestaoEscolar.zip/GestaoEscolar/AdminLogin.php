<?php
session_start();
$conn = new mysqli("localhost", "root", "", "GestaoEscola");

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM admins WHERE email='$email' AND senha='$senha'";
    $res = $conn->query($sql);

    if ($res->num_rows > 0) {
        $_SESSION['admin'] = $email;
        header("Location: dashboardadmin.php");
        exit;
    } else {
        $mensagem = "<div class='alert alert-danger text-center'>E-mail ou senha incorretos!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Login do Administrador</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f2f2f2;
    }

    .card-login {
      max-width: 400px;
      margin: auto;
      margin-top: 8%;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      background-color: #ffffff;
    }

    .titulo-laranja {
      color: #ff8000;
    }

    .btn-laranja {
      background-color: #ff8000;
      color: white;
    }

    .btn-laranja:hover {
      background-color: #e67300;
    }
  </style>
</head>
<body>

  <div class="card card-login">
    <h4 class="text-center titulo-laranja mb-4">Login do Administrador</h4>

    <?php echo $mensagem; ?>

    <form method="POST">
      <div class="mb-3">
        <label class="form-label">E-mail</label>
        <input type="email" name="email" class="form-control rounded-pill" required>
      </div>

      <div class="mb-4">
        <label class="form-label">Senha</label>
        <input type="password" name="senha" class="form-control rounded-pill" required>
      </div>

      <button type="submit" class="btn btn-laranja w-100 rounded-pill mb-3">Entrar</button>

      <div class="text-center">
        <span>Não tem conta?</span>
        <a href="#" class="text-decoration-none titulo-laranja fw-bold" onclick="cadastro()">Cadastrar-se</a>
      </div>
    </form>
  </div>

  <script>
    function cadastro(){
        alert("Só é possivel cadastrar um admintrador pelo banco de dados 😉")
    }
  </script>
</body>
</html>