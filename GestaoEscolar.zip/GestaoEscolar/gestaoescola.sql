-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 07-Jul-2025 às 08:05
-- Versão do servidor: 9.1.0
-- versão do PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `gestaoescola`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `admins`
--

INSERT INTO `admins` (`id`, `nome`, `email`, `senha`) VALUES
(1, 'Andre Luemba', 'andresavio701@gmail.com', 'ae2so0ml0la5');

-- --------------------------------------------------------

--
-- Estrutura da tabela `alunos`
--

DROP TABLE IF EXISTS `alunos`;
CREATE TABLE IF NOT EXISTS `alunos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `idade` int DEFAULT NULL,
  `genero` char(1) DEFAULT NULL,
  `id_sala` int DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_sala` (`id_sala`)
) ;

--
-- Extraindo dados da tabela `alunos`
--

INSERT INTO `alunos` (`id`, `nome`, `idade`, `genero`, `id_sala`, `email`, `senha`) VALUES
(3, 'Amilton Landu', 18, 'M', 1, 'amilton@gmail.com', '$2y$10$0vUde/NHVs0Qk.tv.crmHuaq1gfz2WVQTxcXdi7B2NvwpWJDjvjTC'),
(7, 'André Luemba', 18, 'M', 1, 'andreluemba@gmail.com', '$2y$10$0LZ3bieio5Okjk6b8b/9t.i6RlbbAIdf3cNC634rfTZr6/IPUGIAS'),
(4, 'Alexandre Jose', 20, 'M', 1, 'alexandrejose@gmail.com', '$2y$10$1dNrSYejJbOZ6TIL4lPlJ.oesZBTKtYCv4.OKxcArZ4fupgn9gIqK'),
(5, 'Marineth Paulo', 19, 'F', 1, 'marinethpaulo@gmail.com', '$2y$10$.XxQyl5pqKXqYrHkpwFbN.Uknd64OizQDa/.viFBJSEwUeoGgfygO'),
(6, 'João Floriano', 18, 'M', 1, 'florianodaniel574@gmail.com', '$2y$10$KEN3oitt27LfJFLJxnxLoOjXoBt9A4.k3W3XXBhftGBcruSXKbJXm');

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplinas`
--

DROP TABLE IF EXISTS `disciplinas`;
CREATE TABLE IF NOT EXISTS `disciplinas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_disciplina` varchar(100) NOT NULL,
  `id_professor` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_professor` (`id_professor`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `disciplinas`
--

INSERT INTO `disciplinas` (`id`, `nome_disciplina`, `id_professor`) VALUES
(1, 'Matematica', 1),
(2, 'TLP', 2),
(3, 'Física', 3),
(4, 'SEAC', 4),
(5, 'TREI', 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `notas`
--

DROP TABLE IF EXISTS `notas`;
CREATE TABLE IF NOT EXISTS `notas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_aluno` int DEFAULT NULL,
  `id_disciplina` int DEFAULT NULL,
  `nota1` decimal(4,2) DEFAULT NULL,
  `nota2` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_disciplina` (`id_disciplina`)
) ;

--
-- Extraindo dados da tabela `notas`
--

INSERT INTO `notas` (`id`, `id_aluno`, `id_disciplina`, `nota1`, `nota2`) VALUES
(1, 1, 1, 15.00, 17.00),
(2, 1, 2, 18.00, 20.00),
(3, 3, 1, 15.00, 17.00),
(4, 3, 2, 15.00, 15.00),
(5, 3, 3, 12.00, 17.00);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professores`
--

DROP TABLE IF EXISTS `professores`;
CREATE TABLE IF NOT EXISTS `professores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `especialidade` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `professores`
--

INSERT INTO `professores` (`id`, `nome`, `especialidade`, `email`, `senha`) VALUES
(1, 'Joao Fernandes', 'Matematica', 'joaofernandes@gmail.com', 'fernandesjoao'),
(2, 'Nelson Tito Mario', 'TLP', 'nelsonmario@gmail.com', '$2y$10$BQWTA84eE/8/TfZjtgI2FeN4nfM53So9X4KkVKqTPXqJZ76pBRiwe'),
(3, 'Inacio Joao', 'Fisica', 'inaciojoao@gmail.com', '$2y$10$glZuJ.gBsfcWMSrrXhlYwu2wlMhz94O86Ase9tDo4GM5Odifsd2Ku'),
(4, 'Acursio Cassongo', 'SEAC', 'acursiocassongo@gmail.com', '$2y$10$iL5wYaXVgRVS50dRJBr/iOI5lE/L44VPK2/SEr23OVU8ti7YfyY76'),
(5, 'Sampaio Andre', 'TREI', 'sampaioandre@gmail.com', '$2y$10$fzsYCoHOgmTYO3WfZOSai.fUSAxfmfKAQc6W1ujPDCPR5c7t2AFwi');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sala`
--

DROP TABLE IF EXISTS `sala`;
CREATE TABLE IF NOT EXISTS `sala` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_sala` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `sala`
--

INSERT INTO `sala` (`id`, `nome_sala`) VALUES
(1, 'A1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo_de_usuario` enum('professor','aluno') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
