<?php
session_start();
include 'menu.php';

$conn = new mysqli("localhost", "root", "", "GestaoEscola");

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$mensagem = "";

function gerarSenhaAleatoria($tamanho = 8) {
    $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#!$';
    return substr(str_shuffle($caracteres), 0, $tamanho);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $genero = $_POST['genero'];
    $id_sala = $_POST['id_sala'];
    $email = $_POST['email'];

    if (isset($_POST['gerar_senha'])) {
        $senha_plana = gerarSenhaAleatoria(); 
    } else {
        $senha_plana = $_POST['senha'];
    }

    $senha_cripto = password_hash($senha_plana, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO alunos (nome, idade, genero, id_sala, email, senha) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisiss", $nome, $idade, $genero, $id_sala, $email, $senha_cripto);

    if ($stmt->execute()) {
        $mensagem = "
        <div class='alert alert-success text-center mt-3'>
          <h5>Aluno cadastrado com sucesso!</h5>
          <p><strong>Nome:</strong> $nome</p>
          <p><strong>Email:</strong> $email</p>
          <p><strong>Senha:</strong> $senha_plana</p>
        </div>";
    } else {
        $mensagem = "<div class='alert alert-danger text-center mt-3'>Erro ao cadastrar: " . $stmt->error . "</div>";
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Cadastrar Aluno</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .bg-laranja {
      background-color: #ff8000;
    }

    .btn-laranja {
      background-color: #ff8000;
      color: white;
    }

    .btn-laranja:hover {
      background-color: #e67300;
      color: white;
    }
  </style>
</head>
<body class="bg-light">

  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">

        <?= $mensagem ?>

        <div class="card shadow">
          <div class="card-header bg-laranja text-white text-center">
            <h4>Cadastro de Aluno</h4>
          </div>

          <div class="card-body">
            <form action="" method="post" id="formCadastro">
              <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" class="form-control" name="nome" placeholder="Insira o nome Completo" required>
              </div>

              <div class="mb-3">
                <label for="idade" class="form-label">Idade</label>
                <input type="number" class="form-control" name="idade" placeholder="Insira a idade" required>
              </div>

              <div class="mb-3">
                <label for="genero" class="form-label">Gênero</label>
                <input type="text" class="form-control" name="genero" placeholder="M ou F" required>
              </div>

              <div class="mb-3">
                <label for="id_sala" class="form-label">ID da Sala</label>
                <input type="number" class="form-control" name="id_sala" placeholder="Insira o id da sala" required>
              </div>

              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" placeholder="email@examplo.com"  required>
              </div>

              <div class="mb-3 senha-area">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" name="senha" placeholder="Insira uma senha forte" id="campoSenha">
              </div>

              <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" name="gerar_senha" id="checkSenha">
                <label class="form-check-label" for="checkSenha">
                  Gerar senha automaticamente
                </label>
              </div>

              <div class="d-grid">
                <button type="submit" class="btn btn-laranja">Cadastrar Aluno</button>
              </div>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>

  <script>
    const checkSenha = document.getElementById('checkSenha');
    const campoSenha = document.getElementById('campoSenha');

    checkSenha.addEventListener('change', function () {
      campoSenha.disabled = this.checked;
      if (this.checked) {
        campoSenha.value = ''; 
      }
    });
  </script>
</body>
</html>