<?php 
session_start();
include 'menu.php';

$conn = new mysqli("localhost", "root", "", "GestaoEscola");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_aluno = $_POST['id_aluno'];
    $id_disciplina = $_POST['id_disciplina'];
    $nota1 = $_POST['nota1'];
    $nota2 = $_POST['nota2'];

    $stmt = $conn->prepare("INSERT INTO notas (id_aluno, id_disciplina, nota1, nota2) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iidd", $id_aluno, $id_disciplina, $nota1, $nota2);

    if ($stmt->execute()) {
        $mensagem = "<div class='alert alert-success'>Notas inseridas com sucesso!</div>";
    } else {
        $mensagem = "<div class='alert alert-danger'>Erro ao inserir notas: " . $stmt->error . "</div>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Inserir Notas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --laranja-principal: #ff8000;
        }
        body {
            background-color: #fdf7f2;
        }
        .bg-laranja {
            background-color: var(--laranja-principal) !important;
        }
        .btn-laranja {
            background-color: var(--laranja-principal);
            border-color: var(--laranja-principal);
            color: white;
        }
        .btn-laranja:hover {
            background-color: #e67300;
            border-color: #e67300;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-laranja text-white">
            <h4 class="mb-0">Inserir Notas do Aluno</h4>
        </div>
        <div class="card-body">
            <?php if (!empty($mensagem)) echo $mensagem; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="id_aluno" class="form-label">ID do Aluno</label>
                    <input type="number" class="form-control" id="id_aluno" name="id_aluno" required>
                </div>
                <div class="mb-3">
                    <label for="id_disciplina" class="form-label">ID da Disciplina</label>
                    <input type="number" class="form-control" id="id_disciplina" name="id_disciplina" required>
                </div>
                <div class="mb-3">
                    <label for="nota1" class="form-label">Nota 1</label>
                    <input type="number" step="0.01" class="form-control" id="nota1" name="nota1" required>
                </div>
                <div class="mb-3">
                    <label for="nota2" class="form-label">Nota 2</label>
                    <input type="number" step="0.01" class="form-control" id="nota2" name="nota2" required>
                </div>
                <button type="submit" class="btn btn-laranja">Salvar Notas</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>