<?php 

session_start();
include 'menu.php';

$conn = new mysqli("localhost", "root", "", "GestaoEscola");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$sql = "SELECT * FROM alunos";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Lista de Alunos</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
    }
    .titulo {
      color: #ff8000;
    }
    .table thead {
      background-color: #ff8000;
      color: white;
    }
  </style>
</head>
<body>

<div class="container mt-5">
  <h2 class="text-center mb-4 titulo">Alunos Cadastrados</h2>

  <?php if ($resultado->num_rows > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered table-hover">
        <thead class="text-center">
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Idade</th>
            <th>Gênero</th>
            <th>Número da Sala</th>
          </tr>
        </thead>
        <tbody>
          <?php while($linha = $resultado->fetch_assoc()): ?>
            <tr>
              <td><?= $linha["id"] ?></td>
              <td><?= $linha["nome"] ?></td>
              <td><?= $linha["idade"] ?></td>
              <td><?= $linha["genero"] ?></td>
              <td><?= $linha["id_sala"] ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="alert alert-warning text-center">Nenhum aluno cadastrado.</div>
  <?php endif; ?>

</div>

<div class="text-center">
    <a href="adicionarnota.php" class="text-decoration-none titulo-laranja fw-bold">Adicionar Nota ao Aluno</a> <br>
    <a href="editaraluno.php" class="text-decoration-none titulo-laranja fw-bold">Editar Dados de um aluno</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>